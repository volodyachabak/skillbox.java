public class Main
{
    public static void main(String[] args)
    {
        Container container = new Container();
        container.count += 7843;

    }

    public Integer sumDigits(Integer number)
    {
        //@TODO: write code here
        return 0;
    }
}
