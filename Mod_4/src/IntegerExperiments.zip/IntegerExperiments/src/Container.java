public class Container
{
    public Integer count;
}